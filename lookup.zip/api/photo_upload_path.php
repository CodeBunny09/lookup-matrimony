<?php
	$path = '/premium-update/';
?>
