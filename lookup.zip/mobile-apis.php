<?php
$url="https://control.msg91.com/api/sendhttp.php?authkey=230502A2fIt69c123&mobiles=+91$mno&message=$message&sender=THEGTE&route=4&country=0";
?>