<ul class="my-match-aside">
                    <li>
                    	<a href="preferred-matches"><i class="fa fa-star-o gt-margin-right-10"></i>Preferred Matches</a>
                    </li>
                	<li>
                    	<a href="one-way-matches"><i class="fa fa-long-arrow-right gt-margin-right-10"></i>One Way Matches</a>
                    </li>
                    <li>
                    	<a href="two-way-matches"><i class="fa fa-exchange gt-margin-right-10"></i>Two Way Matches</a>
                    </li>
                    <li>
                    	<a href="broader-matches"><i class="fa fa-arrows-alt gt-margin-right-10"></i>Broader Matches</a>
                    </li>
                    <li>
                    	<a href="custom-matches"><i class="fa fa-tasks gt-margin-right-10"></i>Custom Matches</a>
                    </li>
                </ul>